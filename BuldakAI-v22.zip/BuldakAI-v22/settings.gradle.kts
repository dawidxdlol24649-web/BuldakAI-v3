rootProject.name = "BuldakAI"
