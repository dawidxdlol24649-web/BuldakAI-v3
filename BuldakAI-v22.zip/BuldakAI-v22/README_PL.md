# BuldakAI — prepSMP (Paper 1.21.11)

Plugin odpowiada na wiadomości zaczynające się od `!buldak`, np. `!buldak hej`.
To osobny bot AI, nie bezpośrednie połączenie z tą rozmową ChatGPT.

## Ważne o darmowym AI
Plugin używa API zgodnego z formatem OpenAI Chat Completions. Przykładowa konfiguracja jest ustawiona na darmowy model OpenRouter, ale darmowe modele, limity i dostępność mogą się zmieniać. Nie ma gwarancji 0 zł ani ciągłej dostępności.

## Budowanie pliku JAR
Wymagane: JDK 21 i Gradle 8.10+ (lub nowszy zgodny z JDK 21), internet do pobrania Paper API.

W katalogu projektu uruchom:
- Windows: `gradle build`
- Linux/macOS: `gradle build`

Plik pojawi się w `build/libs/BuldakAI-1.0.0.jar`.

## Instalacja
1. Zatrzymaj serwer.
2. Wgraj `BuldakAI-1.0.0.jar` do `plugins/`.
3. Uruchom serwer raz, aby utworzył `plugins/BuldakAI/config.yml`.
4. Zatrzymaj serwer i ustaw `api.api-key` w configu.
5. Uruchom serwer ponownie.
6. W grze wpisz `!buldak hej`.

## Bezpieczeństwo klucza
- Klucz API przechowuj tylko w prywatnym `plugins/BuldakAI/config.yml`.
- Nie wysyłaj go na czacie, Discordzie ani na publicznym GitHubie.
- Nie umieszczaj klucza w samym pliku JAR.
- Ustaw limity po stronie dostawcy API, jeśli są dostępne.

## Funkcje
- Trigger `!buldak`.
- Cooldown 8 sekund na gracza.
- 20 wiadomości na gracza na godzinę.
- Limit długości wiadomości i odpowiedzi.
- Krótka pamięć ostatnich wiadomości per gracz.
- Wywołania API poza głównym wątkiem serwera.

## Ograniczenia / testowanie
Projekt korzysta ze starszego `AsyncPlayerChatEvent`, który nadal jest dostępny w API Paper 1.21.11, ale może być oznaczony jako przestarzały. Przetestuj najpierw na kopii serwera. W razie błędu sprawdź konsolę.
